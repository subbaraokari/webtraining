package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cts.entities.Emp;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	JdbcTemplate template;

	@Autowired
	public EmployeeDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}

	@Override
	public Emp insert(Emp e) {
		template.update("insert into emp(eno,name,address) values(?,?,?)", e.getEno(), e.getName(), e.getAddress());
		return e;
	}

	@Override
	public Emp delete(int eno) {
		template.update("delete from emp where eno=?", eno);
		Emp e = getEmployee(eno).get();
		return e;
	}

	@Override
	public Emp update(Emp e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Emp> getEmployees() {

		List<Emp> employees = template.query("select * from emp", new RowMapper<Emp>() {
			

			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				Emp e = new Emp(rs.getInt(1), rs.getString(2), rs.getString(3));
				return e;
			}
		});

		// List<Emp> employees=template.queryForList("select * from emp", Emp.class);
		return employees;
	}

	@Override
	public Optional<Emp> getEmployee(int eno) {
		List<Emp> employees = template.query("select * from emp where eno="+eno, new RowMapper<Emp>() {
			Emp e = null;

			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				e = new Emp();
				e.setEno(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setAddress(rs.getString(3));
				return e;
			}

		});
		Optional<Emp> emp = employees.stream().findFirst();
		return emp;
	}

}
