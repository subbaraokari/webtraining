package com.cts.dao;

import java.util.List;
import java.util.Optional;

import com.cts.entities.Emp;

public interface EmployeeDao {
	 Emp insert(Emp e);
	 Emp delete(int eno);
	 Emp update(Emp e);
	 List<Emp> getEmployees();
	 Optional<Emp> getEmployee(int eno);
}
