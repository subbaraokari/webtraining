package com.cts.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.EmployeeDao;
import com.cts.entities.Emp;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao empDao;
	
	@Autowired
	public EmployeeServiceImpl(EmployeeDao empDao) {
		super();
		this.empDao = empDao;
	}
	@Override
	public Emp insertEmployee(Emp e) {
		Emp e1=empDao.insert(e);
		return e1;
	}
	@Override
	public List<Emp> getEmployees() {
		List<Emp> employees=empDao.getEmployees();
		return employees;
	}
	@Override
	public Emp deleteEmployee(int eno) {
		Emp e=empDao.delete(eno);
		return e;
	}
	@Override
	public Emp getEmployee(int eno) {
		Emp e=empDao.getEmployee(eno).get();
		return e;
	}

}
