package com.cts.services;

import java.util.List;

import com.cts.entities.Emp;

public interface EmployeeService {
	Emp insertEmployee(Emp e);
	List<Emp> getEmployees();
	Emp deleteEmployee(int eno);
	Emp getEmployee(int eno);

}
